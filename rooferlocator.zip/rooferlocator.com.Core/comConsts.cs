﻿namespace rooferlocator.com
{
    public class comConsts
    {
        public const string LocalizationSourceName = "com";
    }
}