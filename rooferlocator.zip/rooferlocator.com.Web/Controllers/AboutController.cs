﻿using System.Web.Mvc;

namespace rooferlocator.com.Web.Controllers
{
    public class AboutController : comControllerBase
    {
        public ActionResult Index()
        {
            return View();
        }
	}
}